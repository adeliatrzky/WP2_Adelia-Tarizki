<?php
class Contoh1 extends CI_Controller
{
 public function index()
 {
 echo "<h1>Perkenalkan</h1>";
 echo"Nama saya Adelia Tarizki
 Saya tingga di daerah Cipinang
 olah raga yang saya sukai adalah
 Bulutangkis";
 }
}